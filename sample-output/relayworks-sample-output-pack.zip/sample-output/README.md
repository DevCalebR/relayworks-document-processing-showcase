# RelayWorks Sample Output Pack

This pack contains real outputs generated from `NIST.AI.600-1-sample.pdf`, a five-page sample of *Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile* (NIST AI 600-1). The sample covers the publication's cover, front matter, table of contents, and opening introduction. The official publication is available from [NIST](https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence) and at [DOI 10.6028/NIST.AI.600-1](https://doi.org/10.6028/NIST.AI.600-1).

## Redistribution basis

NIST AI 600-1 is a NIST Technical Series publication. NIST states that works authored by NIST employees are not subject to copyright protection in the United States and grants a non-exclusive, perpetual, paid-up, royalty-free worldwide right to reprint its Technical Series publications and create derivative works. See [NIST's copyright, fair use, and licensing statement](https://www.nist.gov/open/copyright-fair-use-and-licensing-statements-srd-data-software-and-technical-series-publications).

Republished courtesy of the National Institute of Standards and Technology.

## How these files were produced

RelayWorks processed the sample through its local PDF conversion workflow using the **Knowledge Base** goal. Processing ran on the operator's own machine; the document did not need to be uploaded to a third-party document-processing service.

The pack includes the generated Markdown, HTML, structured JSON, plain text, processing report, goal-oriented output, and extracted images. Image references and structured JSON paths were adjusted only to use portable paths inside this ZIP; local filesystem paths, run identifiers, and timestamps were removed.

Output quality varies by PDF structure, scan quality, embedded text, tables, images, and parser behavior. These files intentionally show the generated results as produced, including extraction imperfections that a developer may want to review.

## Package scope

This ZIP contains outputs only. It does not include the paid RelayWorks FastAPI or Next.js source code, the source PDF, application installation files, customer data, environment files, secrets, or tokens.
