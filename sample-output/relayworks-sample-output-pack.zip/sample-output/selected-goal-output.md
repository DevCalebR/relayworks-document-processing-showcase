# AI Knowledge Base: NIST.AI.600-1-sample.pdf

## Overview
Knowledge-ready content extracted from the source document.

## **NIST Trustworthy and Responsible AI NIST AI 600-1**
# **Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile**

## **Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile**
This publication is available free of charge from: https://doi.org/10.6028/NIST.AI.600-1
![](images/_page_0_Picture_4.jpeg)
## **NIST Trustworthy and Responsible AI NIST AI 600-1**

## **NIST Trustworthy and Responsible AI NIST AI 600-1**
# **Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile**

## **Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile**
This publicaton is available free of charge from: https://doi.org/10.6028/NIST.AI.600-1
July 2024
![](images/_page_1_Picture_4.jpeg)
U.S. Department of Commerce *Gina M. Raimondo, Secretary*
Natonal Insttute of Standards and Technology *Laurie E. Locascio, NIST Director and Under Secretary of Commerce for Standards and Technology*  **About AI at NIST**: The Natonal Insttute of Standards and Technology (NIST) develops measurements, technology, tools, and standards to advance reliable, safe, transparent, explainable, privacy-enhanced, and fair artficial intelligence (AI) so that its full commercial and societal benefits can be realized without harm to people or the planet. NIST, which has conducted both fundamental and applied work on AI for more than a decade, is also helping to fulfill the 2023 Executve Order on Safe, Secure, and Trustworthy AI. NIST established the U.S. AI Safety Insttute and the companion AI Safety Insttute Consortum to contnue the efforts set in moton by the E.O. to build the science necessary for safe, secure, and trustworthy development and use of AI.
*Acknowledgments: This report was accomplished with the many helpful comments and contributons from the community, including the NIST Generatve AI Public Working Group, and NIST staff and guest researchers: Chloe Auto, Jesse Dunietz, Patrick Hall, Shomik Jain, Kamie Roberts, Reva Schwartz, Martn Stanley, and Elham Tabassi.*
#### **NIST Technical Series Policies**

## **NIST Technical Series Policies**
Copyright, Use, and Licensing Statements NIST Technical Series Publication Identifier Syntax
#### **Publicaton History**

## **Publicaton History**
Approved by the NIST Editorial Review Board on 07-25-2024
#### **Contact Informaton**

## **Contact Informaton**
ai-inquiries@nist.gov
National Institute of Standards and Technology Attn: NIST AI Innovation Lab, Information Technology Laboratory 100 Bureau Drive (Mail Stop 8900) Gaithersburg, MD 20899-8900
#### **Additonal Informaton**

## **Additonal Informaton**
Additional information about this publication and other NIST AI publications are available at https://airc.nist.gov/Home.
*Disclaimer: Certain commercial enttes, equipment, or materials may be identfied in this document in order to adequately describe an experimental procedure or concept. Such identficaton is not intended to imply recommendaton or endorsement by the Natonal Insttute of Standards and Technology, nor is it intended to imply that the enttes, materials, or equipment are necessarily the best available for the purpose. Any menton of commercial, non-profit, academic partners, or their products, or references is for informaton only; it is not intended to imply endorsement or recommendaton by any U.S. Government agency.*
### **Table of Contents**

## **Table of Contents**
| Int                                      | roduction                                                                                    | 1             |
|------------------------------------------|----------------------------------------------------------------------------------------------|---------------|
| Ov                                       | erview of Risks Unique to or Exacerbated by GAI                                              | 2             |
| 1.                                       | CBRN Information or Capabilities                                                             | 5             |
| 2.                                       | Confabulation                                                                                | 6             |
| 3.                                       | Dangerous, Violent, or Hateful Content                                                       | 6             |
| 4.                                       | Data Privacy                                                                                 |               |
| 5.                                       | Environmental Impacts                                                                        | 8             |
| 6.                                       | Harmful Bias and Homogenization                                                              | 8             |
| 7.                                       | Human-AI Configuration                                                                       | 9             |
| 8.                                       | Information Integrity                                                                        |               |
| 9.                                       | Information Security                                                                         | 10            |
| 10.                                      | Intellectual Property                                                                        | 11            |
| 11.                                      | Obscene, Degrading, and/or Abusive Content                                                   | 11            |
| 12.                                      |                                                                                              |               |
| 3. Suggested Actions to Manage GAI Risks |                                                                                              | . 12          |
| Appendix A. Primary GAI Considerations   |                                                                                              |               |
| Appendix B. References                   |                                                                                              | . 54          |
|                                          | Ove<br>11.<br>22.<br>33.<br>44.<br>55.<br>66.<br>77.<br>38.<br>99.<br>110.<br>111.<br>Sugend | Confabulation |
#### **1. Introducton**

## **1. Introducton**
This document is a cross-sectoral profile of and companion resource for the AI Risk Management Framework (AI RMF 1.0) for Generatve AI, <sup>1</sup> pursuant to President Biden's Executve Order (EO) 14110 on Safe, Secure, and Trustworthy Artficial Intelligence.<sup>2</sup> The AI RMF was released in January 2023, and is intended for voluntary use and to improve the ability of organizatons to incorporate trustworthiness consideratons into the design, development, use, and evaluaton of AI products, services, and systems.
A *profile* is an implementaton of the AI RMF functons, categories, and subcategories for a specific setng, applicaton, or technology – in this case, Generatve AI (GAI) – based on the requirements, risk tolerance, and resources of the Framework user. AI RMF profiles assist organizatons in deciding how to best manage AI risks in a manner that is well-aligned with their goals, considers legal/regulatory requirements and best practces, and reflects risk management priorites. Consistent with other AI RMF profiles, this profile offers insights into how risk can be managed across various stages of the AI lifecycle and for GAI as a technology.
As GAI covers risks of models or applicatons that can be used across use cases or sectors, this document is an AI RMF cross-sectoral profile. Cross-sectoral profiles can be used to govern, map, measure, and manage risks associated with actvites or business processes common across sectors, such as the use of large language models (LLMs), cloud-based services, or acquisiton.
This document defines risks that are novel to or exacerbated by the use of GAI. Afer introducing and describing these risks, the document provides a set of suggested actons to help organizatons govern, map, measure, and manage these risks.
<sup>1</sup> EO 14110 defines Generatve AI as "the class of AI models that emulate the structure and characteristcs of input data in order to generate derived synthetc content. This can include images, videos, audio, text, and other digital content." While not all GAI is derived from foundaton models, for purposes of this document, GAI generally refers to generatve foundaton models. The foundaton model subcategory of "dual-use foundaton models" is defined by EO 14110 as "an AI model that is trained on broad data; generally uses self-supervision; contains at least tens of billions of parameters; is applicable across a wide range of contexts."
<sup>2</sup> This profile was developed per Secton 4.1(a)(i)(A) of EO 14110, which directs the Secretary of Commerce, actng through the Director of the Natonal Insttute of Standards and Technology (NIST), to develop a companion resource to the AI RMF, NIST AI 100–1, for generatve AI.